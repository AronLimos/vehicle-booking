const jwt = require('jsonwebtoken');

// Middleware to verify JWT token
const verifyToken = (req, res, next) => {
    const token = req.headers['authorization'];
    if (!token) return res.status(403).json({ message: 'Access Denied' });

    jwt.verify(token.split(" ")[1], process.env.JWT_SECRET, (err, decoded) => {
        if (err) return res.status(401).json({ message: 'Invalid Token' });

        // 🔹 Explicitly set `userId` in `req.user`
        req.user = { 
            userId: decoded.userId,  
            role: decoded.role 
        };

        if (!req.user.userId) {
            return res.status(403).json({ message: "Unauthorized: User ID missing from token" });
        }

        next();
    });
};

// Middleware to restrict access to specific roles
const authorizeRoles = (...roles) => {
    return (req, res, next) => {
        if (!roles.includes(req.user.role)) {
            return res.status(403).json({ message: 'Forbidden' });
        }
        next();
    };
};

module.exports = { verifyToken, authorizeRoles };
